#include "delete_entry.h"
/*
#include "add_entry.h"
#include "file_handling.h"
#include "search_record.h"
#include "display.h"
*/
#define MAX_CONTACTS 1024
#define MAX_NAME_CHARS 40
#define MAX_PHONE_CHARS 12
#define MAX_EMAIL_CHARS 30
#define FALSE 0
#define TRUE 1
